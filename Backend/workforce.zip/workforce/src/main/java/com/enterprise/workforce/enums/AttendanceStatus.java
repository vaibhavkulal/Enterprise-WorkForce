package com.enterprise.workforce.enums;

public enum AttendanceStatus {
    PRESENT,
    ABSENT,
    LATE,
    HALF_DAY,
    HOLIDAY
}
