package com.enterprise.workforce.enums;


public enum RoleType {
    ADMIN,
    HR,
    EMPLOYEE
}
