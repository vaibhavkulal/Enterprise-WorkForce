package com.enterprise.workforce.service.impl;

import com.enterprise.workforce.entity.AuditLog;
import com.enterprise.workforce.repository.AuditLogRepository;
import lombok.RequiredArgsConstructor;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.stereotype.Service;

import java.time.LocalDateTime;

@Service
@RequiredArgsConstructor
public class AuditLogService {

    private final AuditLogRepository auditLogRepository;

    public Page<AuditLog> getAllLogs(Pageable pageable) {
        return auditLogRepository.findAll(pageable);
    }

    public Page<AuditLog> getLogsByUser(String username, Pageable pageable) {
        return auditLogRepository.findAllByUsername(username, pageable);
    }

    public void saveLog(String username, String action, String entity, Long entityId, String role, String ip) {
        AuditLog log = AuditLog.builder()
                .username(username)
                .action(action)
                .entity(entity)
                .entityId(entityId)
                .timestamp(LocalDateTime.now())
                .ipAddress(ip)
                .role(role)
                .build();
        auditLogRepository.save(log);
    }
}
