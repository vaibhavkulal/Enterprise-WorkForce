package com.enterprise.workforce.aop;

import com.enterprise.workforce.annotations.Auditable;
import com.enterprise.workforce.entity.AuditLog;
import com.enterprise.workforce.repository.AuditLogRepository;
import com.enterprise.workforce.service.impl.AuditLogService;
import lombok.RequiredArgsConstructor;
import org.aspectj.lang.JoinPoint;
import org.aspectj.lang.annotation.AfterReturning;
import org.aspectj.lang.annotation.Aspect;
import org.springframework.security.core.Authentication;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.stereotype.Component;

import java.time.LocalDateTime;
import java.util.Optional;

@Aspect
@Component
@RequiredArgsConstructor
public class AuditAspect {

    private final AuditLogService auditLogService;
    private final AuditLogRepository repo;

    // ✅ Basic audit when @Auditable used
    @AfterReturning("@annotation(com.enterprise.workforce.annotations.Auditable)")
    public void logAction(JoinPoint joinPoint) {
        Authentication auth = SecurityContextHolder.getContext().getAuthentication();
        String username = auth != null ? auth.getName() : "SYSTEM";
        String role = auth != null ? auth.getAuthorities().toString() : "UNKNOWN";

        String action = joinPoint.getSignature().getName();
        String entity = joinPoint.getTarget().getClass().getSimpleName();

        auditLogService.saveLog(username, action, entity, null, role, "127.0.0.1");
    }

    // ✅ Advanced audit version (with returned result)
    @AfterReturning(pointcut = "@annotation(aud)", returning = "result")
    public void after(JoinPoint jp, Auditable aud, Object result) {
        String user = Optional.ofNullable(SecurityContextHolder.getContext().getAuthentication()).map(Authentication::getName).orElse("anonymous");

        AuditLog log = new AuditLog();
        log.setUsername(user);
        log.setAction(aud.action());
        log.setEntity(jp.getSignature().toShortString()); // ✅ replaced setTarget → setEntity
        log.setTimestamp(LocalDateTime.now());
        log.setDetails(result != null ? result.toString() : null);

        repo.save(log);
    }
}
