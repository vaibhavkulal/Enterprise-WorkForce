package com.enterprise.workforce.enums;

public enum EmploymentStatus {
    ACTIVE,
    INACTIVE,
    TERMINATED,
    RETIRED
}
