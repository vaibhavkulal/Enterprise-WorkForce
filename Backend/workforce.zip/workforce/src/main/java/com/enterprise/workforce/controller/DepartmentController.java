package com.enterprise.workforce.controller;

import com.enterprise.workforce.entity.Department;
import com.enterprise.workforce.repository.DepartmentRepository;
import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.tags.Tag;
import lombok.RequiredArgsConstructor;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.server.ResponseStatusException;

import java.util.List;
import java.util.Map;

@RestController
@RequestMapping("/api/department")
@RequiredArgsConstructor
@Tag(name = "Department Management", description = "APIs for managing departments done by HR, ADMIN")
public class DepartmentController {

    private final DepartmentRepository departmentRepository;

    // Create Department
    @Operation(summary = "Create a new department")
    @PreAuthorize("hasAnyRole('ADMIN','HR')")
    @PostMapping("/create")
    public ResponseEntity<?> createDepartment(@RequestBody Department department) {
        if (departmentRepository.findByName(department.getName()).isPresent()) {
            return ResponseEntity.badRequest().body(Map.of("error", "Department name already exists"));
        }

        Department saved = departmentRepository.save(department);
        return ResponseEntity.status(HttpStatus.CREATED).body(Map.of("message", "Department created successfully", "department", saved));
    }

    // Update Department
    @Operation(summary = "Update an existing department by ID")
    @PreAuthorize("hasAnyRole('ADMIN','HR')")
    @PutMapping("/update/{id}")
    public ResponseEntity<?> updateDepartment(@PathVariable Long id, @RequestBody Department updatedDepartment) {
        Department department = departmentRepository.findById(id).orElseThrow(() -> new ResponseStatusException(HttpStatus.NOT_FOUND, "Department not found"));

        department.setName(updatedDepartment.getName());
        department.setDescription(updatedDepartment.getDescription());
        Department saved = departmentRepository.save(department);

        return ResponseEntity.ok(Map.of("message", "Department updated successfully", "department", saved));
    }

    // Delete Department
    @Operation(summary = "Delete a department by ID")
    @PreAuthorize("hasAnyRole('ADMIN','HR')")
    @DeleteMapping("/delete/{id}")
    public ResponseEntity<?> deleteDepartment(@PathVariable Long id) {
        if (!departmentRepository.existsById(id)) {
            throw new ResponseStatusException(HttpStatus.NOT_FOUND, "Department not found");
        }

        departmentRepository.deleteById(id);
        return ResponseEntity.ok(Map.of("message", "Department deleted successfully"));
    }

    // Get All Departments
    @Operation(summary = "Get all departments")
    @PreAuthorize("hasAnyRole('ADMIN','HR')")
    @GetMapping("/all")
    public ResponseEntity<Map<String, Object>> getAllDepartments() {
        List<Department> departments = departmentRepository.findAll();
        return ResponseEntity.ok(Map.of("count", departments.size(), "departments", departments));
    }

    //  Get Department by ID
    @Operation(summary = "Get department by ID")
    @PreAuthorize("hasAnyRole('ADMIN','HR')")
    @GetMapping("/{id}")
    public ResponseEntity<?> getDepartmentById(@PathVariable Long id) {
        Department department = departmentRepository.findById(id).orElseThrow(() -> new ResponseStatusException(HttpStatus.NOT_FOUND, "Department not found"));

        return ResponseEntity.ok(Map.of("department", department));
    }
}
