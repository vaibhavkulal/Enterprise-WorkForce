package com.enterprise.workforce.enums;

public enum PayrollStatus {
    PENDING_APPROVAL,
    APPROVED,
    PAID
}
