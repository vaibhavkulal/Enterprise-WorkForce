package com.enterprise.workforce.dto;

import lombok.Data;

import java.math.BigDecimal;

@Data
public class PayrollDto {
    private Long id;
    private Long employeeId;
    private BigDecimal grossSalary;
    private BigDecimal deductions; // e.g., PF, professional tax
    private BigDecimal tax; // computed tax
    private BigDecimal netSalary; // gross - deductions - tax
    private String month;
    // getters/setters
}
