package com.enterprise.workforce;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class WorkforceManagementApplication {

	public static void main(String[] args) {
		SpringApplication.run(WorkforceManagementApplication.class, args);
	}

}
